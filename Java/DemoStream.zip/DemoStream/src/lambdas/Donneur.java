package lambdas;

public interface Donneur {

    void donner(Personne receveur);

}
